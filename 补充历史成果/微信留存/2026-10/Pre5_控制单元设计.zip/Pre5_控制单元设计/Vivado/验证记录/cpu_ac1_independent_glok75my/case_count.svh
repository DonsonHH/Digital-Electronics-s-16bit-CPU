localparam CASES = 48;
