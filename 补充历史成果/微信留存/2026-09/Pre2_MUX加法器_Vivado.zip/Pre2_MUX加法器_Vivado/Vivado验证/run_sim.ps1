param([string]$VivadoBin='C:\AMDDesignTools\2025.2\Vivado\bin')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
  & (Join-Path $VivadoBin 'xvlog.bat') --sv rtl/modules.v rtl/tb_pre2.sv
  if($LASTEXITCODE -ne 0){throw 'HDL compilation failed'}
  & (Join-Path $VivadoBin 'xelab.bat') tb_pre2 -s pre2_sim -debug typical
  if($LASTEXITCODE -ne 0){throw 'Elaboration failed'}
  & (Join-Path $VivadoBin 'xsim.bat') pre2_sim -tclbatch sim.tcl -wdb pre2.wdb
  if($LASTEXITCODE -ne 0){throw 'Simulation failed'}
  if(-not (Select-String -LiteralPath 'xsim.log' -Pattern 'PASS MUX1=8 FA1=8 ADD4=512 MUX16=2040 ADD16=2040 LINK=2040 TOTAL=6648' -Quiet)){throw 'PASS receipt missing'}
} finally {Pop-Location}
