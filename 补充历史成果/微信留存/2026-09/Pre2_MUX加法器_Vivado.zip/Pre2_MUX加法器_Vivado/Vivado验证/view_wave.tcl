set task_dir [file dirname [file normalize [info script]]]
open_wave_database [file join $task_dir pre2.wdb]
create_wave_config
add_wave /tb_pre2/a /tb_pre2/b /tb_pre2/sel /tb_pre2/cin /tb_pre2/mux_g /tb_pre2/mux_r /tb_pre2/sum_g /tb_pre2/sum_r /tb_pre2/cout_g /tb_pre2/expected_add /tb_pre2/linked_sum
