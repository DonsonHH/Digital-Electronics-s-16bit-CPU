open_vcd pre2.vcd
log_vcd /tb_pre2/*
log_wave -r /tb_pre2/*
run all
close_vcd
quit
