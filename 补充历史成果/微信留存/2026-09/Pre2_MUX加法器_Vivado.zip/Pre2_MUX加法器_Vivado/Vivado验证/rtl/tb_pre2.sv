`timescale 1ns/1ps
module tb_pre2;
  reg [15:0] a=0,b=0; reg sel=0,cin=0;
  wire [15:0] mux_g,mux_r,sum_g,sum_r,linked_sum;
  wire cout_g,cout_r,linked_cout;
  reg [15:0] expected_mux; reg [16:0] expected_add,expected_link;
  reg [3:0] a4=0,b4=0; reg ci4=0;
  wire [3:0] s4g,s4r; wire c4g,c4r;
  reg bit_a=0,bit_b=0,bit_c=0;
  wire bit_mg,bit_mr,bit_sum,bit_cout;
  integer checks=0, mux16_checks=0,add16_checks=0,link_checks=0;
  integer i,j,k,fd;
  reg [31:0] rng=32'h20260914;
  mux_gate mg(a,b,sel,mux_g); mux_rtl mr(a,b,sel,mux_r);
  ripple_adder ag(a,b,cin,sum_g,cout_g); adder_rtl ar(a,b,cin,sum_r,cout_r);
  ripple_adder link(a,mux_g,1'b0,linked_sum,linked_cout);
  ripple_adder #(.W(4)) ag4(a4,b4,ci4,s4g,c4g);
  adder_rtl #(.W(4)) ar4(a4,b4,ci4,s4r,c4r);
  mux_gate #(.W(1)) mg1(bit_a,bit_b,bit_c,bit_mg);
  mux_rtl #(.W(1)) mr1(bit_a,bit_b,bit_c,bit_mr);
  full_adder fa1(bit_a,bit_b,bit_c,bit_sum,bit_cout);
  function automatic [31:0] next_random(input [31:0] state);
    reg [31:0] x;
    begin x=state^(state<<13);x=x^(x>>17);next_random=x^(x<<5);end
  endfunction
  task automatic test16(input [15:0] aa,bb,input ss,cc);
    begin
      a=aa;b=bb;sel=ss;cin=cc;
      expected_mux=ss?bb:aa;
      expected_add={1'b0,aa}+{1'b0,bb}+cc;
      expected_link={1'b0,aa}+{1'b0,expected_mux};
      #10;
      if(mux_g!==expected_mux || mux_r!==expected_mux) $fatal(1,"MUX16 mismatch");
      if({cout_g,sum_g}!==expected_add || {cout_r,sum_r}!==expected_add) $fatal(1,"ADD16 mismatch");
      if({linked_cout,linked_sum}!==expected_link) $fatal(1,"LINK mismatch");
      mux16_checks++;add16_checks++;link_checks++;checks+=3;
      $fdisplay(fd,"%0t,%04h,%04h,%b,%b,%04h,%04h,%05h,%05h,%05h",$time,a,b,sel,cin,mux_g,mux_r,{cout_g,sum_g},{cout_r,sum_r},{linked_cout,linked_sum});
    end
  endtask
  initial begin
    fd=$fopen("vectors.csv","w");
    if(!fd) $fatal(1,"Cannot open output");
    $fdisplay(fd,"time_ps,a,b,sel,cin,mux_gate,mux_rtl,adder_gate,adder_rtl,linked");
    test16(16'h0000,16'h0000,0,0);
    test16(16'h0000,16'h0000,1,1);
    test16(16'h00ff,16'h0001,0,0);
    test16(16'h00ff,16'h0001,1,0);
    test16(16'hffff,16'h0001,0,0);
    test16(16'h7fff,16'h0001,1,0);
    test16(16'haaaa,16'h5555,0,0);
    test16(16'haaaa,16'h5555,1,0);
    for(i=0;i<8;i++) begin
      {bit_a,bit_b,bit_c}=i;#10;
      if(bit_mg !== (bit_c?bit_b:bit_a) || bit_mr !== (bit_c?bit_b:bit_a)) $fatal(1,"MUX1 mismatch");
      if({bit_cout,bit_sum} !== ({1'b0,bit_a}+{1'b0,bit_b}+bit_c)) $fatal(1,"FA1 mismatch");
      checks+=2;
    end
    for(i=0;i<16;i++) for(j=0;j<16;j++) for(k=0;k<2;k++) begin
      a4=i;b4=j;ci4=k;#10;
      if({c4g,s4g} !== (i+j+k) || {c4r,s4r} !== (i+j+k)) $fatal(1,"ADD4 mismatch");
      checks++;
    end
    for(i=0;i<16;i++) begin
      test16(16'h0001<<i,~(16'h0001<<i),0,0);
      test16(16'h0001<<i,~(16'h0001<<i),1,1);
    end
    for(i=0;i<1000;i++) begin
      rng=next_random(rng);a=rng[15:0];
      rng=next_random(rng);b=rng[15:0];
      test16(a,b,0,rng[16]);
      test16(a,b,1,rng[16]);
    end
    $fclose(fd);
    $display("PASS MUX1=8 FA1=8 ADD4=512 MUX16=%0d ADD16=%0d LINK=%0d TOTAL=%0d seed=20260914(hex)",mux16_checks,add16_checks,link_checks,checks);
    $finish;
  end
endmodule
